<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title>Ruparel Realty - Real Estate Builder and Developer in Mumbai</title>
  <meta name="description" content="Ruparel Realty is the leading real estate builder and property developer in Mumbai, known for providing quality residential apartments and commercial projects.">
  <meta name="referrer" content="origin"/>
  <link rel="icon" type="image/png" href="/images/favicon.png">
    <!--<link rel="canonical" href="https://ruparel.in" />-->
    
    <link rel="canonical" href="https://ruparel.in/signals/iwl.js">
    
  <link href="/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="/css/animate.css" rel="stylesheet" type="text/css" />
<link href="/css/slick.css" rel="stylesheet" type="text/css" />
<link href="/css/styles.css?v=1.3" rel="stylesheet" type="text/css" />
<link href="/css/responsive.css?v=1.4" rel="stylesheet" type="text/css" />  
    
  
<meta name="google-site-verification" content="7f_HmoTLHpKhYghUJOQTuG53f8DX-1ofs-a2l06s_qw" />

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-T8P9837G');</script>
<!-- End Google Tag Manager -->


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-43VV33ME9P"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-43VV33ME9P');
</script>
  
  <script type="text/javascript">
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "uibdwijheu");
</script>
  <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Ruparel Realty",
  "alternateName": "Ruparel Realty Real Estate",
  "url": "https://ruparel.in/",
  "logo": "https://ruparel.in/images/logonew.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "7045451110",
    "contactType": "sales",
    "areaServed": "IN",
    "availableLanguage": ["en","Hindi","Marathi"]
  },
  "sameAs": [
    "https://www.facebook.com/RuparelRealty/",
    "https://www.instagram.com/ruparelrealty",
    "https://www.youtube.com/@ruparelrealty9962",
    "https://www.linkedin.com/company/ruparelrealty-liveiconic/?originalSubdomain=in"
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "WebPage",
  "url": "https://ruparel.in/signals/iwl.js",
  "name": "Ruparel Realty - Real Estate Builder and Developer in Mumbai"
}
</script>

  
</head>

<style>
    .about-container {
    
    position: relative;
    min-height: 80vh;
}

.read-more {
        margin: 0px auto;
    display: block;
    display: flex;
    justify-content: center;
    align-items: center;
    width: 20%;
    margin-top: 3%;
    background: linear-gradient(80deg, rgba(238, 166, 87, 1) 0%, rgba(199, 32, 49, 1) 100%);
}

.read-more:hover {
    color:#fff;
}

</style>

<body>
  <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T8P9837G"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

  <!--<div id="loader"></div>-->
  <div class="mainpage">

    <header id="header" class="fixed-top">
  <div class="container">
    <nav class="navbar navbar-expand-md">
      <!-- Brand -->
      <a class="navbar-brand" href="/"
        ><img src="/images/logonew.png" alt="Ruparel"
      /></a>
      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a
              class="nav-link"
              href="https://www.facebook.com/RuparelRealty/?fref=ts"
              target="_blank"
              ><i class="fa fa-facebook" aria-hidden="true"></i
            ></a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              href="https://www.instagram.com/ruparelrealty/"
              target="_blank"
              ><i class="fa fa-instagram" aria-hidden="true"></i
            ></a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              href="https://www.linkedin.com/company/ruparelrealty-liveiconic/?originalSubdomain=in"
              target="_blank"
              ><i class="fa fa-linkedin" aria-hidden="true"></i
            ></a>
          </li>
          <li class="nav-item calltxt">
            <a
              class="nav-link"
              href="https://www.youtube.com/channel/UCaq-5z2BASZZ5M92ti6ZM7Q"
              target="_blank"
              ><i class="fa fa-youtube-play" aria-hidden="true"></i
            ></a>
          </li>
          <li class="nav-item p-2">
            <a href="tel:+917045451110" style="color: #575757"
              ><i class="fa fa-phone" aria-hidden="true" style="
    transform: rotate(90deg);
"></i> : +91 7045 451
              110</a
            >
          </li>
        </ul>
      </div>
      <div class="button"><span class="btn-open" href="#"></span></div>
    </nav>
  </div>
  <div class="overlay">
    <ul>
      <li class="active"><a href="/">Home</a></li>
      <li><a href="/about-us">About us</a></li>
      <li><a href="/projects">Projects</a></li>
      <li><a href="/ruparel-realty-reviews">Reviews</a></li>
      <li><a href="/media">Media</a></li>
      <li><a href="/careers/">Careers</a></li>
      <li><a href="/contact">Contact us</a></li>
    </ul>
  </div>
</header>
    
    <section class="section about-container d-flex align-items-center dark-bg">

		<div class="container">

			<div class="row position-relative align-items-center ht-100">

				<div class="col-lg-10 mx-auto">

					<!-- <div class="subheading">About Us</div> -->

					<h2 class="heading text-center">Oops! That page can’t be found.</h2>

					<div class="">
						
						<a class="btn btn-outline-light read-more" href="/"> <span>GO TO HOME</span> <i class="bi bi-arrow-right"></i></a>

					</div>

				</div>

			</div>

		</div>

	</section>
    
    
    </div>  
    <a href="https://api.whatsapp.com/send?phone=918657447623&amp;text=Hi%2C%20I%20would%20like%20to%20know%20more%20about%20your%20projects." class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>
<a href="tel:+917045451110" class="float1" data-toggle="" data-target="" style="
    transform: rotate(
90deg);
">
<i class="fa fa-phone my-float"></i>
</a>
<a href="javascript:void(0)" id="scroll" style="display: inline;"><span></span></a> 
<footer>
   <div class="container">
      <div class="row">
         <div class="col-lg-5 col-sm-6 col-12">
            <div class="foot-logo">
               <a href="/"
                  ><img src="/images/Ruparel-logo-white.png" alt="Ruparel"
                  /></a>
            </div>
            <ul>
               <li>
                  <h3>Company Info</h3>
                  <a href="/about-us">About Us</a>
                  <a href="/projects">Projects</a>
                  <a href="/careers/">Careers</a>
                  <a href="/ruparel-realty-reviews">Ruparel Realty Reviews</a>
                  <h3 class="pt-3">Typology</h3>
                  <a href="https://ruparel.in/1-bhk-in-mumbai">1 BHK</a>
                  <a href="https://ruparel.in/2-bhk-in-mumbai">2 BHK</a>
                  <a href="https://ruparel.in/3-bhk-in-mumbai">3 BHK</a>
                  <a href="https://ruparel.in/4-bhk-in-mumbai">4 BHK</a>
                  
                  <h3 class="pt-3">Useful links</h3>
                  <a href="/media">Media</a>
                  <a href="/blog/">Blog</a>
                  <a href="/loyaltyrewardsprogram/" >Loyalty Rewards Program</a>
               </li>
               <li>
                  
                  
                  <h3>Properties in Mumbai</h3>
                  <a href="https://ruparel.in/properties-in-mulund">Properties in Mulund</a>
                  <a href="https://ruparel.in/properties-in-chembur">Properties in Chembur</a>
                  <a href="https://ruparel.in/properties-in-kandivali">Properties in Kandivali</a>
                  <a href="https://ruparel.in/properties-in-borivali">Properties in Borivali</a>
                  <a href="https://ruparel.in/properties-in-malad">Properties in Malad</a>
                  <a href="https://ruparel.in/properties-in-byculla">Properties in Byculla</a>
                  <a href="https://ruparel.in/properties-in-kurla">Properties in Kurla</a>
                  <a href="https://ruparel.in/properties-in-santacruz-west">Properties in Santacruz West</a>
                  <a href="https://ruparel.in/properties-in-dadar-east">Properties in Dadar East</a>
                  <a href="https://ruparel.in/properties-in-ghatkopar">Properties in Ghatkopar</a>
                  <a href="https://ruparel.in/properties-in-parel">Properties in Parel</a>
                  <a href="https://ruparel.in/properties-in-sion">Properties in Sion</a>
                  <a href="https://ruparel.in/properties-in-matunga-west">Properties in Matunga West</a>
                  <a href="https://ruparel.in/properties-near-bkc">Properties Near BKC</a>
                  <!--<a href="https://ruparel.in/sea-facing-apartments-in-mumbai">Sea Facing Apartments in Mumbai</a>-->
                  <!--<a href="https://ruparel.in/residential-properties-in-mumbai">Residential Properties in Mumbai</a>-->
                  <!--<a href="https://ruparel.in/commercial-properties-in-mumbai">Commercial Properties in Mumbai</a>-->
               </li>
            </ul>
         </div>
         <div class="col-lg-3 col-sm-6 col-12">
            <h4>
               <a href="tel:+917045451110" style="color: white">+91 7045 451 110</
                  ><br />
               info@ruparel.in
            </h4>
            <p>
               Contact<br />
               CORPORATE OFFICE
            </p>
            <p>
               Ruparel Iris, Next to Smart Bazaar, Opp, Senapati Bapat Marg, Matunga
               West, Mumbai, Maharashtra 400016
            </p>
            <p>
               Media : <a href="mailto:marketing@ruparel.in">marketing@ruparel.in</a
                  ><br />
               Sales : <a href="mailto: sales@ruparel.in"> sales@ruparel.in</a>
            </p>
            <br />
      
           <ul>
               
               <li style="width:100%">
                  
                  
                  <h3>Apartments in Mumbai</h3>
                 
                  <a href="https://ruparel.in/sea-facing-apartments-in-mumbai">Sea Facing Apartments in Mumbai</a>
                  <a href="https://ruparel.in/residential-properties-in-mumbai">Residential Properties in Mumbai</a>
                  <a href="https://ruparel.in/commercial-properties-in-mumbai">Commercial Properties in Mumbai</a>
               </li>
            </ul>
            
         </div>
         <div class="col-lg-4 col-sm-12 col-12">
            <div class="row">
               <div class="col-10">
                  <!-- Contact form (kept as in your HTML) -->
                  <div class="form-container" id="bottom-form">
                     <div id="error" style="color: white; text-align: center"></div>
                     <!-- <form
                        id="reg-form2"
                        action=""
                        name="reg-form"
                        method="POST"
                        novalidate
                        onsubmit="handleFormSubmit(event,'bottom-form'); return false"
                        > -->
                     <!--<form-->
                     <!--   id="reg-form2" method="POST" action="https://ruparel.in/thankyou.php" name="reg-form2" onsubmit="return form_validate('reg-form2');" novalidate-->
                     <!--   >-->
                         <form id="reg-form2" method="POST" action="thankyou.php" onsubmit="" name="reg-form2">
                        <div class="form-group col-md-12 pd0-m">
                           <div class="input-group" style="display: block">
                              <div class="input-container">
                                 <input
                                    onkeydown="return /[a-zA-Z]/i.test(event.key)"
                                    type="text"
                                    class="form-control"
                                    name="fname"
                                    placeholder="Name"
                                    required
                                    />
                                 <input type="hidden" name="name" value="Register Form" />
                              </div>
                           </div>
                           <label for="name" class="error" id="nameerror"></label>
                        </div>
                        <div class="form-group col-md-12 pd0-m">
                           <div class="input-group" style="display: block">
                              <div class="input-container">
                                 <input
                                    type="email"
                                    class="form-control"
                                    name="email"
                                    placeholder="Email"
                                    required
                                    />
                              </div>
                              <label for="email" class="error" id="emailerror"></label>
                           </div>
                        </div>
                        <div class="form-group col-md-12 pd0-m">
                           <div class="input-group" style="display: block">
                              <div class="input-container">
                                 <input
                                    type="number"
                                    class="form-control"
                                    name="mobile"
                                    placeholder="Mobile"
                                    oninput="this.setCustomValidity('')" pattern="[6-9]{1}[0-9]{9}" required
                                    
                                    />
                              </div>
                              
                           </div>
                        </div>
                        <div class="form-group col-md-12 pd0-m">
                           <div class="input-group" style="display: block">
                              <div class="input-container">
                                 <input
                                    type="text"
                                    name="message"
                                    class="form-control message"
                                    placeholder="Comment"
                                    required
                                    />
                              </div>
                              <label
                                 for="message"
                                 class="error"
                                 id="messageerror"
                                 ></label>
                           </div>
                        </div>
                        <div class="form-group col-md-12 pd0-m">
                           <div
                              class="input-group"
                              style="
                              display: flex;
                              align-items: center;
                              flex-wrap: nowrap;
                              "
                              >
                              <input
                                 type="checkbox"
                                 id="consent"
                                 name="consent"
                                 checked
                                 required
                                 style="margin-right: 8px"
                                 />
                              <label
                                 for="consent"
                                 style="color: white; margin: 0; font-size: 10px"
                                 >
                             By submitting, I authorize Ruparel Realty to collect and use my personal information and contact me via SMS, RCS, Call and WhatsApp regarding this project and other promotional offers. I understand this consent overrides my DNC/NDNC registration.
                              </label>
                           </div>
                        </div>
                        <div class="form-group col-md-12 pd0-m">
                        <input
                           type="submit"
                           value="Submit"
                           
                           class="btn btn-default contact-btn"
                           />
                           </div>
                     </form>
                  </div>
               </div>
               <div class="col-2 soccial-icons-ps">
                  <div class="social clearfix position-relative">
                     <a
                        href="https://www.facebook.com/RuparelRealty/?fref=ts"
                        target="_blank"
                        ><i class="fa fa-facebook" aria-hidden="true"></i
                        ></a>
                     <a href="https://www.instagram.com/ruparelrealty/" target="_blank"
                        ><i class="fa fa-instagram" aria-hidden="true"></i
                        ></a>
                     <a
                        href="https://www.linkedin.com/company/ruparelrealty-liveiconic/?originalSubdomain=in"
                        target="_blank"
                        ><i class="fa fa-linkedin" aria-hidden="true"></i
                        ></a>
                     <a
                        href="https://www.youtube.com/channel/UCaq-5z2BASZZ5M92ti6ZM7Q"
                        target="_blank"
                        ><i class="fa fa-youtube-play" aria-hidden="true"></i
                        ></a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <hr style="color: #fff" />
      <!-- Disclaimer / Terms / Privacy overlays -->
      <div class="row">
         <div class="col-md-4">
            <div class="disclaimer-overlay" id="disclaimerOverlay">
               <div class="disclaimer-text">
                  <p>Disclaimer</p>
                  <p>
                     Disclaimer: The Real Estate (Regulation and Development) Act, 2016
                     has been introduced and the rules and regulations notified
                     thereunder ("RERA") on 1st May 2017. The process of updating our
                     website is being initiated to ensure full compliance with the law.
                     The advertisements available on the website were created prior to
                     RERA came into force and thus contains/may contain promotional
                     material related to future phases of the project. The offerings
                     outlined in those advertisements in whatever form may not be a
                     part of the initial phase of the project and may be delivered in
                     later phases or on completion of the Project. The present content
                     on the website(s), specifications and amenities including but not
                     limited to visuals, pictures, images/ renderings/maps are purely
                     indicative and informative in nature and only an architect's
                     impression and only indicative of the envisaged development and
                     not actual depiction of buildings/landscapes etc. And shall not be
                     considered as our offer/promise/commitment of any nature in
                     respect of the project the same is subject to approval from local
                     authorities. The common areas and amenities that have been shown
                     in any advertisement, audio visuals and/or any type of
                     communication in any form whatsoever is/are for the entire Project
                     and not specific for any particular building or phase of the
                     Project and that the common areas and amenities will not be
                     available on completion of the first phase of the Project or later
                     phases. The common areas and amenities shall be available for the
                     entire project and will be developed in a phase-wise manner, over
                     a period of time. The details of the projects undertaken by the
                     company including the brochures, plans, elevations, images,
                     projections, details, descriptions, contents pertaining to the
                     projects are being modified in terms of the stipulations/
                     recommendations under the Real Estate Act 2016 and rules made
                     thereunder (RERA). You are required to verify all the details,
                     including area, amenities, services, terms of sales, payments and
                     other relevant terms independently with the company sales team, by
                     physically visiting the project site.Any decision regarding
                     booking of the apartment/s in the project by you, until the
                     project is registered under RERA, relying upon the contents of
                     this website shall be solely at your costs and consequences.
                     Ruparel Realty and or its directors, employees, are not liable for
                     any consequence of any action taken by the viewer relying on such
                     material/information on this web.
                  </p>
                  <!-- Add the rest of your disclaimer content here -->
                  <button id="closeDisclaimer">I AGREE</button>
               </div>
            </div>
            <p id="showDisclaimer">Disclaimer</p>
         </div>
         <br />
         <br />
         <div class="col-md-4">
            <div class="disclaimer-overlay" id="disclaimerOverlayterm">
               <div class="disclaimer-text">
                  <p>Terms and Conditions</p>
                  <h3 style="font-size: 18px">
                     WEBSITE TERMS AND CONDITIONS OF USE WITH RUPAREL REALTY WEBSITES.
                     PLEASE READ THESE TERMS AND CONDITIONS CAREFULLY BEFORE USING THIS
                     SITE.
                  </h3>
                  <br />
                  <h2 style="font-size: 16px">ABOUT US</h2>
                  <p>
                     www.ruparel.in is a site operated by Ruparel Realty and its group
                     companies (that is, its affiliates, subsidiaries, ultimate holding
                     company, and its subsidiaries) ("we," "our," "us," or "Ruparel").
                  </p>
                  <br />
                  <h2 style="font-size: 16px">TERMS OF WEBSITE USE</h2>
                  <p>
                     These terms of use (together with the documents referred to
                     herein) set out the terms on which you may make use of our website
                     www.ruparel.in and any other website or mobile application
                     operated by us ("Our Sites"), whether as a guest or a registered
                     user. Use of Our Sites includes accessing, browsing, or
                     registering to use Our Sites. By proceeding to view Our Sites or
                     any part of it, you acknowledge that you have read, understood,
                     and accepted these terms, which shall constitute the entire
                     binding agreement between you and Ruparel. These terms may be
                     varied by Ruparel from time to time, and the revised terms will be
                     deemed to apply at the relevant time in respect of your
                     registration and/or use of Our Sites. Please read these terms
                     carefully before you start to use Our Sites, as these will apply
                     to your use. If you do not agree to these terms, you must not use
                     Our Sites.
                  </p>
                  <br />
                  <h2 style="font-size: 16px">CHANGES TO THESE TERMS</h2>
                  <p>
                     We may revise these terms at any time by amending this page.
                     Please check this page from time to time to take notice of any
                     changes we made, as they are binding on you.
                  </p>
                  <br />
                  <h2 style="font-size: 16px">ACCURACY OF INFORMATION ON OUR SITE</h2>
                  <p>
                     We may update Our Sites from time to time and may change the
                     content at any time. Although we make reasonable efforts to update
                     the information on Our Sites, please note that any of the content
                     may be out of date at any given time, and we are under no
                     obligation to update it. We do not guarantee that Our Sites, or
                     their content, will be free from errors or omissions. Ruparel
                     excludes all liability for any errors or omissions in the content
                     to the fullest extent permitted by law. The information contained
                     on Our Sites is provided for general guidance and illustrative
                     purposes only. It is not intended to amount to advice on which you
                     should rely. While reasonable care has been taken in providing
                     this information, Ruparel and its related companies,
                     representatives, consultants, agents, and where applicable, the
                     sellers or lessors of a property whose agents we may be, accept no
                     responsibility for and exclude any liability for, any loss or
                     damage arising out of or related to the accuracy or completeness
                     of any information contained on Our Sites. You should take
                     appropriate steps to verify any information contained on Our Sites
                     by inspecting the property, relevant documentation, and seeking
                     proper legal, tax, and financial advice from a qualified
                     professional adviser. Nothing on Our Sites shall be regarded or
                     taken as legal or financial advice.
                  </p>
                  <br />
                  <h2 style="font-size: 16px">ACCESSING OUR SITE</h2>
                  <p>
                     Our Sites are made available free of charge. We do not guarantee
                     that Our Sites, or any content on them, will always be available
                     or uninterrupted. We reserve the right to suspend, withdraw,
                     discontinue, or change all or any part of Our Sites without
                     notice.
                  </p>
                  <br />
                  <h2 style="font-size: 16px">INTELLECTUAL PROPERTY RIGHTS</h2>
                  <p>
                     <br />
                     We are the owner or licensee of all intellectual property rights
                     in Our Sites and the material published on them. All copyright,
                     database rights, and other intellectual property rights that
                     subsist in the design, layout, processes, functions, data, and
                     content of Our Sites belong to Ruparel or our licensors,
                     information providers, or contributors. No part of Our Sites,
                     their content, or any of their underlying software and databases
                     may be copied, reproduced, or shared without prior written
                     consent.
                  </p>
                  <br />
                  <h2 style="font-size: 16px">LIMITATION OF OUR LIABILITY</h2>
                  <p>
                     <br />
                     To the extent permitted by law, we exclude all conditions,
                     warranties, representations, or other terms that may apply to Our
                     Sites or any content on them, whether express or implied. We will
                     not be liable to any user for any loss or damage arising under or
                     in connection with the use of Our Sites or reliance on any content
                     displayed on them.
                  </p>
                  <br />
                  <h2 style="font-size: 16px">VIRUSES</h2>
                  <p>
                     We do not guarantee that Our Sites will be secure or free from
                     bugs or viruses. You must not misuse Our Sites by introducing
                     malicious or harmful material.
                  </p>
                  <br />
                  <h2 style="font-size: 16px">LINKS</h2>
                  <p>
                     Links to other sites and resources are provided for your
                     information only. We assume no responsibility for the content of
                     websites linked to Our Sites and are not liable for any loss or
                     damage arising from your use of them.
                  </p>
                  <br />
                  <h2 style="font-size: 16px">INDEMNITY</h2>
                  <p>
                     If you breach any of these terms or do any act that affects our
                     rights or those of third parties, we reserve the right to
                     terminate your access to Our Sites. You agree to indemnify and
                     hold us harmless from any claim or demand arising out of such
                     breaches.
                  </p>
                  <br />
                  <h2 style="font-size: 16px">OTHER APPLICABLE TERMS</h2>
                  <p>
                     For information about Ruparel’s data protection practices, please
                     read Ruparel’s Privacy Policy at
                     https://ruparel.in/privacy-policy.
                  </p>
                  <br />
                  <h2 style="font-size: 16px">APPLICABLE LAW</h2>
                  <p>
                     These terms and their formation shall be governed by the laws of
                     India, and the Courts of Mumbai shall have exclusive jurisdiction
                     over any disputes. Thank you for visiting Our Sites.
                  </p>
                  <button id="closeDisclaimerterm">I AGREE</button>
                  <br /><br /><br />
               </div>
            </div>
            <p id="showDisclaimerterm">Terms and Conditions</p>
         </div>
         <br /><br />
         <div class="col-md-4">
            <div class="disclaimer-overlay" id="disclaimerOverlayed">
               <div class="disclaimer-text">
                  <p>Privacy Policy</p>
                  <p>
                     Privacy Policy: We collect information from you when you register
                     on our site or fill out a form. When filling out a form on our
                     site, for any of the above-mentioned reasons, you may be asked to
                     enter your: name, e-mail address and phone number. You may,
                     however, visit our site anonymously. Any of the information we
                     collect from you is to personalize your experience, to improve our
                     website and to improve customer service. Any data collected will
                     be/ will not be shared with any 3rd party.
                  </p>
                  <!-- Add the rest of your disclaimer content here -->
                  <button id="closeDisclaimered">Close</button>
               </div>
            </div>
            <p id="showDisclaimered">Privacy Policy</p>
         </div>
      </div>
   </div>
</footer>    

  <!-- Core libs (keep only one jQuery) -->
<!--<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"
    integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="text/javascript" src="/js/popper.min.js"></script>
<script type="text/javascript" src="/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/js/slick.js"></script>
<script type="text/javascript" src="/js/wow.min.js"></script>
<script type="text/javascript" src="/js/purecounter.js"></script>
<script type="text/javascript" src="/js/isotope.min.js"></script>
<script type="text/javascript" src="/js/tilt.jquery.js"></script>
<script type="text/javascript" src="/js/custom.js"></script>
<script type="text/javascript" src="/js/cookie.js"></script>
<script type="text/javascript" src="/js/url-tracking.js"></script>
<!--<script src="/chat/widget.js"></script>-->



<script>
    $(document).ready(function() {

        Delete_Cookie('formfilled');

    });
    </script>

<!-- Global helpers from your HTML -->
<script>


  // Open modal on load if needed
  $(document).ready(function(){
    // $('#myModal').modal('show'); // (left commented as in your source)
  });

  // Disclaimer overlays (moved from <head>)
  $(document).ready(function () {
    $('#showDisclaimer').on('click touchstart', function () { $('#disclaimerOverlay').fadeIn(); });
    $('#closeDisclaimer').on('click touchstart', function () { $('#disclaimerOverlay').fadeOut(); });
    $('#showDisclaimered').on('click touchstart', function () { $('#disclaimerOverlayed').fadeIn(); });
    $('#closeDisclaimered').on('click touchstart', function () { $('#disclaimerOverlayed').fadeOut(); });
    $('#showDisclaimerterm').on('click touchstart', function () { $('#disclaimerOverlayterm').fadeIn(); });
    $('#closeDisclaimerterm').on('click touchstart', function () { $('#disclaimerOverlayterm').fadeOut(); });
  });

</script>


<script type="text/javascript">
    function form_validate(elm) {
        jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', true);
        setTimeout(function() {
            jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', false);
        }, 5000);
        var name = jQuery('#' + elm + ' input[name="fname"]').val();
        var mobileno = jQuery('#' + elm + ' input[name="mobile"]').val();
        var emailid = jQuery('#' + elm + ' input[name="email"]').val();
        var message = jQuery('#' + elm + ' textarea[name="message"]').val();
        var fsource = jQuery('#' + elm + ' input[name="source"]').val();

        var current_url = location.hostname;

        if (name == "") {
            //alert("Please Enter Your Name");
            return false;
        }

        mobileno = mobileno.replace(/[^0-9]/g, '');
        if (mobileno.length != 10) {
            //alert("Please Enter 10 Digit Mobile Number");
            return false;
        }
        var atpos = emailid.indexOf("@");
        var dotpos = emailid.lastIndexOf(".");
        if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= emailid.length) {
            return false;
        }

        if (message == undefined) {
            message = "";
        }
        if (name != "" && mobileno != "") {
            $("#pageloader").fadeIn();
            if (fsource == 'Download Brochure') {
                //document.getElementById('bro-pdf').click();
                window.open(document.getElementById('bro-pdf').href, '_blank');
            }


            return true;
        }
        return false;
    }

    function submitForm(elm) {
        document.createElement('form').submit.call(document.getElementById(elm));
    }
    
    
//     setTimeout(function(){
//   document.querySelector('.eqClick').click()
// }, 5000)
    </script></body>